"""
tables for pythia
"""
